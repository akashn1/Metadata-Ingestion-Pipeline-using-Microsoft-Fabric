import json
from pathlib import Path

def test_sample_metadata_contract():
    data = json.loads((Path(__file__).parents[1] / "metadata/sample_entity_metadata.json").read_text())
    assert data["project"] == "Metadata Ingestion Pipeline"
    entity = data["entities"][0]
    required = {"entity_id", "active", "source_type", "staging_path", "target_table", "write_mode"}
    assert required <= entity.keys()
    assert entity["write_mode"] in {"append", "merge", "overwrite"}
